﻿using System;

namespace _01._Generic_Box_of_String
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            for(int i = 0; i < n; i++)
            {
                string input = Console.ReadLine();
                var newBox = new Box<string>(input);
                Console.WriteLine(newBox);
            }
        }
    }
}
