 // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  var firebaseConfig = {
    apiKey: "AIzaSyDplzsSNez3iP1xSgsa6sqHH7bXaDOPF7o",
    authDomain: "destinations-exam-3c840.firebaseapp.com",
    projectId: "destinations-exam-3c840",
    storageBucket: "destinations-exam-3c840.appspot.com",
    messagingSenderId: "242155988072",
    appId: "1:242155988072:web:bd88181ba0adabda0c07dd",
    measurementId: "G-9F4DVBD99B"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();