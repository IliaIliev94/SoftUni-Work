 // TODO
 const auth = firebase.auth();
 const baseURL = `https://team-manager-50fc6.firebaseio.com`;
 const app = Sammy('#main', function() {

    this.use('Handlebars', 'hbs');

     this.get('#/home', function(context) {

        const userInfo = JSON.parse(localStorage.getItem('userInfo'));
        if(userInfo) {
            const {uid, email} = userInfo;
            context.loggedIn = true;
            context.username = email;

        }
         loadPartials(context)
         .then(function() {
            this.partial('../templates/home/home.hbs');
         });
     });

     this.get('#/login', function(context) {
         loadPartials(context)
         .then(function() {
            this.partial('../templates/login/loginPage.hbs')
         });
     });

     this.get('#/register', function(context) {
         loadPartials(context)
         .then(function() {
            this.partial('../templates/register/registerPage.hbs');
         });
     });

     this.get('#/about', function(context) {
         loadPartials(context)
         .then(function() {
            this.partial('../templates/about/about.hbs')
         });
     });

     this.post('#/register', function(context) {
         const {username, password, repeatPassword} = context.params;
         if(password !== repeatPassword) {
             alert('Password and requested password fields must be equal the same!');
             return;
         }
         auth.createUserWithEmailAndPassword(username, password)
            .then((user) => {
                // Signed in 
                // ...
            })
            .catch((error) => {
                var errorCode = error.code;
                var errorMessage = error.message;
                // ..
            });
     })

     this.post('#/login', function(context) {
        const {username, password} = context.params;
        firebase.auth().signInWithEmailAndPassword(username, password)
            .then(({user : {uid, email}}) => {
                localStorage.setItem('userInfo', JSON.stringify({uid, email}));
                context.redirect('#/home');
            })
            .catch((error) => {
                alert(`${error.code} - ${error.message}`);
            });
                });

    this.get('#/logout', function(context) {
        auth.signOut()
        .then((response) => {
            localStorage.removeItem('userInfo');
            context.redirect('#/home')
        })
        .catch(err => alert(err));
    });

    this.get('#/', function(context) {
        context.redirect('#/home');
    });
 });

(() => {
    app.run('#/home');
})();

function loadPartials(context) {
    return context.loadPartials({
        'header': '../templates/common/header.hbs',
        'footer': '../templates/common/footer.hbs',
        'registerForm': '../templates/register/registerForm.hbs',
        'loginForm': '../templates/login/loginForm.hbs'
    });
}

