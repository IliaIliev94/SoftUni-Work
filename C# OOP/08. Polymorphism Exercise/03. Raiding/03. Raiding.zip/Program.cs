﻿using System;
using _03._Raiding.Core;

namespace _03._Raiding
{
    public class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
