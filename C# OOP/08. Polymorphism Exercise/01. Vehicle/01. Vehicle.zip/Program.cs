﻿using System;
using System.Linq;
using _01._Vehicle.Core;
namespace _01._Vehicle
{
    class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
