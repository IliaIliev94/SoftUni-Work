﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01._Vehicle.Core
{
    public interface IEngine
    {
        void Run();
    }
}
