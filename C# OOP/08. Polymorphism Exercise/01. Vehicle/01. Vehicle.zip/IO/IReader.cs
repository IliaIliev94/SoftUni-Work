﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01._Vehicle.IO
{
    public interface IReader
    {
        string CustomReadLine();
    }
}
