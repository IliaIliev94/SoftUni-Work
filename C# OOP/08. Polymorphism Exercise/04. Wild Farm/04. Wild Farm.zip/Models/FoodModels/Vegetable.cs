﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04._Wild_Farm.Models
{
    public class Vegetable : Food
    {
        public Vegetable(string type, int quantity) : base(type, quantity)
        {

        }
    }
}
