﻿using System;
using _04._Wild_Farm.Core;

namespace _04._Wild_Farm
{
    class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
