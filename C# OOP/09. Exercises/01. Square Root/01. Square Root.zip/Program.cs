﻿using System;

namespace _01._Square_Root
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int n = (int)Math.Sqrt(int.Parse(Console.ReadLine()));
            }
            catch(FormatException Ex)
            {
                Console.WriteLine("Invalid number");
            }
            finally
            {
                Console.WriteLine("Good bye");
            }
        }
    }
}
