﻿namespace Visitor
{
    public class Director : Employee
    {
        public Director()
            : base("Edward", 35000.0, 16)
        { }
    }
}