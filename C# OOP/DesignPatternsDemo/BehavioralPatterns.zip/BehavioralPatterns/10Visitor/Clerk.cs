﻿namespace Visitor
{
    public class Clerk : Employee
    {
        public Clerk()
            : base("Harry", 25000.0, 14)
        { }
    }
}