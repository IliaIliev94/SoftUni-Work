﻿namespace Visitor
{
    public class President : Employee
    {
        public President()
            : base("Damond", 45000.0, 21)
        { }
    }
}