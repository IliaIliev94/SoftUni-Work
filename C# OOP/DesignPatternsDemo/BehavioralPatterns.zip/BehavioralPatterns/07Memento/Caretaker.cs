﻿namespace Memento
{
    public class Caretaker
    {
        public Memento Memento { set; get; }
    }
}