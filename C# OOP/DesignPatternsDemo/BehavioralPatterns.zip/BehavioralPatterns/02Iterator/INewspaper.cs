﻿namespace Iterator
{
    public interface INewspaper
    {
        IIterator CreateIterator();
    }
}
