﻿namespace Flyweight
{
    public interface IShape
    {
        void Print();
    }
}