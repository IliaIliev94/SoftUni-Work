﻿namespace Builder
{
    public class Car
    {
        public int TopSpeedMPH { get; set; }
        
        public int HorsePower { get; set; }
        
        public string MostImpressiveFeature { get; set; }
    }
}