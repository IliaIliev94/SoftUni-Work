﻿namespace FactoryMethod
{
    public abstract class ISavingsAccount
    {
        public decimal Balance { get; set; }
    }
}