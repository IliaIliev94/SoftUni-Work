﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DependencyInjection
{
    public interface IPrintService
    {
        void Print(string path);
    }
}
