﻿namespace SimpleFactory
{
    public enum FanType
    {
        TableFan,
        CeilingFan,
    }
}