﻿namespace AbstractFactory
{
    public class NationalSavingsAccount : ISavingsAccount
    {
    }
}