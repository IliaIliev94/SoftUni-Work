﻿namespace AbstractFactory
{
    public interface ILoanAccount
    {
    }
}