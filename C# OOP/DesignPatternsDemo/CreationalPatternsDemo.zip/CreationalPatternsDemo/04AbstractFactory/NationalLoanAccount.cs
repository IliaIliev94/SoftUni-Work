﻿namespace AbstractFactory
{
    public class NationalLoanAccount : ILoanAccount
    {
    }
}