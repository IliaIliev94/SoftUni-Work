﻿namespace AbstractFactory
{
    public class CitiSavingsAccount : ISavingsAccount
    {
    }
}