﻿namespace AbstractFactory
{
    public class CitiLoanAccount : ILoanAccount
    {
    }
}