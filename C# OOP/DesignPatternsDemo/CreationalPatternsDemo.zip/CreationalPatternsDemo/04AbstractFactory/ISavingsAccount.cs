﻿namespace AbstractFactory
{
    public interface ISavingsAccount
    {
    }
}